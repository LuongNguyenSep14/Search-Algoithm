+ Mở commandline chuyển thư mục làm việc sang thư mục chứa source code.
+ Chạy file main.py

***Có thể xem video demo ở link sau***
Link demo: https://youtu.be/YnhuyJ9-rpQ